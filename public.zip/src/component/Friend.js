
import React  from 'react';
import { NavLink } from 'react-router-dom';
import {
    
  Container,
  Row,
  Col,
 
} from 'reactstrap';


import react from   "./header.css";


const Friend = () => {
  
  return (
  
<h-me>
    
<div class=" setting ">
<h1>Friend</h1>
</div>

</h-me>


  );


}

export default Friend;
import React, { useState,useEffect } from 'react';
import { NavLink,Link, Redirect } from 'react-router-dom';
import { useTimerConsumer,useTimerConsumerUpdate } from './MyComponent/TimerContext'
import {useCharacterConsumer,useCharacterConsumerUpdate} from './MyComponent/CharacterContext'
import {useMainConsumer,useMainConsumerUpdate} from './MyComponent/MainContext'
import {

  Container,
  Row,
  Col,
 
} from 'reactstrap';
import Get from './Get';


import react from   "./header.css";
import Post from './Post';


const Home = (props) => {
    //console.log("Home rendring")
    const {isActive,loser}=useTimerConsumer();
    const {setIsActive,resetTime,setLoser}=useTimerConsumerUpdate();
    const {setCon,setAlpha}=useMainConsumerUpdate()

    useEffect(()=>{
        //console.log("isActive in useEffect in Home.js",isActive)
    },[isActive])
    useEffect(()=>{
        console.log("calling resttime from Homwnew=",loser.name,",",loser.out)
        console.log("Time Reset@@@@@@@@@@@@@  3")
        resetTime()
    },[loser])
         const onClick=()=>{
             console.log("function calling*** in HOME.js",loser.name,",",loser.out)
             setCon(false)
             setLoser({name:'You',out:false})
             console.log("***************SET IS ACTIVE 3***************")
         setIsActive(true)
         //resetTime()
        } 
  
  return (
  
<h-me>
{/* <Post/> */}

{/* <Get/> */}
{/* <!----banner-sectopn---> */}
   <div class="section_card">
       <div class="container">
       <div class=" row">
       <div className="col-lg-6 mb-5 offset-md-3"><div className="logo-wrapper"><img src="assets/img/logo-01copy.png" alt="" /><h1>The Never Ending Game</h1></div></div>
       
           <div class="col-md-4">
                   <div class="card man1 card1 ">
                            <div class=" row m-1">          

                       <div class="col-md-7">
                           <div class="left">
                               <h3 class="play_heading_n">Play Online </h3>
                               <p class="text-white m_p">Play With  Anyone</p>
                               <a class="play_btn" href="#">Play</a>
                           </div>
                       </div>
                       <div class="col-md-5">
                           <div class="image_r">
                               <img class="earth1" src="assets/img/earth.png" alt="" />
                           </div>
                       </div>
                   </div>
               </div>
               </div>
                 <div class="col-md-4">
                   <div class=" card man1 card2 ">
                            <div class=" row m-1">          

                       <div class="col-md-7">
                           <div class="left">
                               <h3 class="play_heading_n">Play With  Friends </h3>
                                  <p class="text-white m_p">Play With  you own people</p>
                               <NavLink class="play_btn" to="/playfrind">Play</NavLink>
                           </div>
                       </div>
                       <div class="col-md-5">
                           <div class="image_r">
                               <img class="earth" src="assets/img/friend.png" alt="" />
                           </div>
                       </div>
                   </div>
               </div>
               </div>
                 <div class="col-md-4">
                   <div class=" card man1 card3 ">
                            <div class=" row m-1">          

                       <div class="col-md-7">
                           <div class="left">
                               <h3 class="play_heading_n">VS Computer </h3>
                               <p class="text-white  m_p">Play With  Computer</p>
                                <NavLink class="play_btn" to="/main" onClick={onClick}>Play</NavLink> 
                           </div>
                       </div>
                       <div class="col-md-5">
                           <div class="image_r">
                               <img class="earth" src="assets/img/computer-set.png" alt="" />
                           </div>
                       </div>
                   </div>
               </div>
               </div> 
           </div>
      
       </div>


        {/* <div className="level-contaienr">
            <div className="level-wrapper">
            <span>X</span>
            <h2>Select level</h2>
                <ul className="level-list">
                <li><a href="#">Easy</a></li>
                <li><a href="#">Medium</a></li>
                <li><a href="#">Difficult</a></li>
                <li><a href="#">Expert</a></li>
                <li><a href="#">Genius</a></li>
                </ul>
            </div>
        </div> */}

   </div>
   
   
    
</h-me>


  );


}

export default Home;
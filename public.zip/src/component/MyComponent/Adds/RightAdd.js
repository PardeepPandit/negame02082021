import React,{Fragment} from 'react'

export const RightAdd = () => {
    return (
        <Fragment>
            <div className="col-lg-2 toright">
                <img src="assets/img/ad5.jpg" alt="" className="img-fluid" />
            </div>
        </Fragment>
    )
}

export default RightAdd
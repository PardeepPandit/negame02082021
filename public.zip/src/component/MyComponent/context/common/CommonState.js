import React,{useReducer,useContext,useEffect} from 'react';
import commonReducer from '../common/commonReducer'
import CommonContext from '../common/commonContext'
import axios from 'axios'
import{
    SET_INPUT_TEXT
} from '../../../../type'; 


const CommonState=({children})=>{
  const initialState={
   inputText:null
  };
 
  const [state,dispatch]=useReducer(commonReducer,initialState);

  const setInputText=(text)=>{
    dispatch({
        type:SET_INPUT_TEXT,
        payload:text
    })
}
  return (
    <CommonContext.Provider
    value={{
    inputText:state.inputText,
    setInputText
      }}>
      {children}
    </CommonContext.Provider>
  )
}

export default CommonState;
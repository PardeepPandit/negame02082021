import {createContext} from 'react'

const masterContext=createContext()
 export default masterContext
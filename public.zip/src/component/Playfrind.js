
import React  from 'react';
import { NavLink } from 'react-router-dom';

import {
    
  Container,
  Row,
  Col,
 
} from 'reactstrap';


import react from   "./header.css";




const Playfrind = () => {
  
  return (
  
<div>
    
<div className=" setting ">

<header className="play">
    <div className="container-fluid">
      <div className="row">
        <div className="col-md-4">
          <div className="serc_h_fr">
            <input type="text"  placeholder="Serch Neegame" />
          </div>
        </div>
        <div className="col-md-8">
          <div className="row">
            <div className="col-md-8">
              <div classNameName="friend">

       <ul className="nav nav-tabs">
    <li className="nav-item">
      <NavLink className="nav-link active" to="/request">My Friends</NavLink>
    </li>
    <li className="nav-item">
    <NavLink className="nav-link " to="/request">friend Request</NavLink>
    </li>
    <li className="nav-item">
    <NavLink className="nav-link " to="/sent">Sent Request</NavLink>
    </li>
  </ul>
              </div>
            </div>
            <div className="col-md-4">
              <div className="acount">
               <div className="user"> <img src="assets/img/usericon.png" alt="user" /> <span>Ved</span>
               <i className="fa fa-plus"></i>
               <i className="fa fa-bell-o" aria-hidden="true"></i>
               </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </header>
  {/* ------header-end----- */}

{/* ------main------ */}
<div className="main">
            <div class="container-fluid ms">
              <div class="row">
                <div class="col-md-4">
                  <div class="side_left">
                    <div class="s_top">
                      <strong>All Friend</strong>
                      <strong class="pull-right"><i class="fa fa-cog" aria-hidden="true"></i></strong>
                    </div>
                    <div class="friends">
                    <div class="friends_all">
                      <div class="friends_img1">
                        <img src="assets/img/usericon.png" alt="img"/>
                      </div>
                      <div class="friends_img">
                      <p><strong>VedPal</strong> <pan class="pull-right">1 W</pan></p>
                      <p><span ><img class="mutl" src="assets/img/usericon.png" alt="imh"/></span> <span>10  mutual friends</span></p>
                      
                      <a class="con" href="">Conform</a>
                      <a class="del" href="">Dlete</a>
                      </div>
                      
                    </div>
                
                  <div class="friends_all">
                      <div class="friends_img1">
                        <img src="assets/img/usericon.png" alt="img"/>
                      </div>
                      <div class="friends_img">
                      <p><strong>VedPal</strong> <pan class="pull-right">1 W</pan></p>
                      <p><span ><img class="mutl" src="assets/img/usericon.png" alt="imh"/></span> <span>10  mutual friends</span></p>
                      
                      <a class="con" href="">Conform</a>
                      <a class="del" href="">Dlete</a>
                      </div>
                      
                    </div>
                
                  <div class="friends_all">
                      <div class="friends_img1">
                        <img src="assets/img/usericon.png" alt="img"/>
                      </div>
                      <div class="friends_img">
                      <p><strong>VedPal</strong> <pan class="pull-right">1 W</pan></p>
                      <p><span ><img class="mutl" src="assets/img/usericon.png" alt="imh"/></span> <span>10  mutual friends</span></p>
                      
                      <a class="con" href="">Conform</a>
                      <a class="del" href="">Dlete</a>
                      </div>
                      
                    </div>
                
                  <div class="friends_all">
                      <div class="friends_img1">
                        <img src="assets/img/usericon.png" alt="img"/>
                      </div>
                      <div class="friends_img">
                      <p><strong>VedPal</strong> <pan class="pull-right">1 W</pan></p>
                      <p><span ><img class="mutl" src="assets/img/usericon.png" alt="imh"/></span> <span>10  mutual friends</span></p>
                      
                      <a class="con" href="">Conform</a>
                      <a class="del" href="">Dlete</a>
                      </div>
                      
                    </div>
                
                  <div class="friends_all">
                      <div class="friends_img1">
                        <img src="assets/img/usericon.png" alt="img"/>
                      </div>
                      <div class="friends_img">
                      <p><strong>VedPal</strong> <pan class="pull-right">1 W</pan></p>
                      <p><span ><img class="mutl" src="assets/img/usericon.png" alt="imh"/></span> <span>10  mutual friends</span></p>
                      
                      <a class="con" href="">Conform</a>
                      <a class="del" href="">Dlete</a>
                      </div>
                      
                    </div>
                
                  <div class="friends_all">
                      <div class="friends_img1">
                        <img src="assets/img/usericon.png" alt="img"/>
                      </div>
                      <div class="friends_img">
                      <p><strong>VedPal</strong> <pan class="pull-right">1 W</pan></p>
                      <p><span ><img class="mutl" src="assets/img/usericon.png" alt="imh"/></span> <span>10  mutual friends</span></p>
                      
                      <a class="con" href="">Conform</a>
                      <a class="del" href="">Dlete</a>
                      </div>
                      
                    </div>
                  
                  <div class="friends_all">
                      <div class="friends_img1">
                        <img src="assets/img/usericon.png" alt="img"/>
                      </div>
                      <div class="friends_img">
                      <p><strong>VedPal</strong> <pan class="pull-right">1 W</pan></p>
                      <p><span ><img class="mutl" src="assets/img/usericon.png" alt="imh"/></span> <span>10  mutual friends</span></p>
                      
                      <a class="con" href="">Conform</a>
                      <a class="del" href="">Dlete</a>
                      </div>
                      
                    </div>
            
                  <div class="friends_all">
                      <div class="friends_img1">
                        <img src="assets/img/usericon.png" alt="img"/>
                      </div>
                      <div class="friends_img">
                      <p><strong>VedPal</strong> <pan class="pull-right">1 W</pan></p>
                      <p><span ><img class="mutl" src="assets/img/usericon.png" alt="imh"/></span> <span>10  mutual friends</span></p>
                      
                      <a class="con" href="">Conform</a>
                      <a class="del" href="">Dlete</a>
                      </div>
                      
                    </div>
              
                    </div>
                    
                  </div>
                  
                </div>




                {/* ========8=start===== */}
                <div class="col-md-8">
                  <div class="right-containr">
                    <div class="ma_contant">
        
                    <div class="tab-content">
            <div id="home" class="container tab-pane active">
            <h3 className="frien_d">Online Friends</h3>
            <div class="myfriends">
              
              <div class="user_avel">
              <a href="#">
                <img src="assets/img/usericon.png"  alt="av"/> <span><strong>Vedpal</strong></span> <span class="av pull-right"> Available  <span class="cri"></span></span>
                </a>
              </div>
              <div class="user_avel">
              <a href="#">
                <img src="assets/img/usericon.png"  alt="av"/> <span><strong>Vedpal</strong></span> <span class="av pull-right"> Available  <span class="cri"></span></span>
                </a>
              </div>
              <div class="user_avel">
              <a href="#">
                <img src="assets/img/usericon.png"  alt="av"/> <span><strong>Vedpal</strong></span> <span class="av pull-right"> Available  <span class="cri"></span></span>
                </a>
              </div>
              <div class="user_avel">
              <a href="#">
                <img src="assets/img/usericon.png"  alt="av"/> <span><strong>Vedpal</strong></span> <span class="av pull-right"> Available  <span class="cri"></span></span>
                </a>
              </div>
              <div class="user_avel">
              <a href="#">
                <img src="assets/img/usericon.png"  alt="av"/> <span><strong>Vedpal</strong></span> <span class="av pull-right"> Available  <span class="cri"></span></span>
                </a>
              </div>
              <div class="user_avel">
              <a href="#">
                <img src="assets/img/usericon.png"  alt="av"/> <span><strong>Vedpal</strong></span> <span class="av pull-right"> Available  <span class="cri"></span></span>
                </a>
              </div>
              <div class="user_avel">
              <a href="#">
                <img src="assets/img/usericon.png"  alt="av"/> <span><strong>Vedpal</strong></span> <span class="av pull-right"> Available  <span class="cri"></span></span>
                </a>
              </div>
              <div class="user_avel">
              <a href="#">
                <img src="assets/img/usericon.png"  alt="av"/> <span><strong>Vedpal</strong></span> <span class="av pull-right"> Available  <span class="cri"></span></span>
                </a>
              </div>
            </div>
            </div>
            <div id="menu1" class="container tab-pane fade"><br/>
              <h3>Menu 1</h3>
              <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
            </div>
            <div id="menu2" class="container tab-pane fade"><br/>
              <h3>Menu 2</h3>
              <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
            </div>
          </div>
        </div>
              
                    </div>
                  </div>
                  
                </div>
              </div>
              </div>
              </div>
  </div>
  



  );


}

export default Playfrind;
import React from 'react';

const Suport = () => {
    return(
<div>
            <div class="hero-wrap hero-wrap-2"  >
                <div class="overlay"></div>
                <div class="container">
                    <div class="row no-gutters slider-text align-items-end justify-content-center">
                    <div class="col-md-9  mb-5 text-center">
                        <h2 class="mb-0 bread">Support Us</h2>
                        <p class="breadcrumbs mb-0"><span class="mr-2"><a href="index.html">Home <i class="fa fa-chevron-right"></i></a></span> <span>Support  <i class="fa fa-chevron-right"></i></span></p>
                    
                    </div>
                    </div>
                </div>
            </div>
        
            <section class="ftco-section1 bg-light">
               <div class="container">
                        <div class="row">    
                            <div class="col-lg-4">
                                <div class="card">
                                <div class="card-image">
                                    <div class="wrap">
                                    <img class="img-fluid" src="assets/img/4.jpg" alt="image 1"/>
                                </div>
                                </div> 
                                <div class="card-content bg-light text-dark">
                                <span class="card-title">Lorem Ipsum Text</span>         
                                <button type="button" id="show" data-target="show1" class="show btn btn-custom float-right" aria-label="Left Align"><i class="fa fa-ellipsis-v"></i></button>
                                </div>
                                <div class="card-reveal show1">
                                <span class="card-title">Card Title</span> <button type="button" class="close ms" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                <p>Here is some more information about this product that is only revealed once clicked on.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card">
                            <div class="card-image">
                            <div class="wrap">
                                    <img class="img-fluid" src="assets/img/2.jpg" alt="image 2"/>      
                                    </div>
                                    </div> 
                                    <div class="card-content bg-light text-dark">
                                    <span class="card-title">Lorem Ipsum Text</span>       
                                    <button type="button" id="show2" data-target="show2" class="show btn btn-custom float-right" aria-label="Left Align"><i class="fa fa-ellipsis-v"></i></button>
                            </div>
                                    
                        <div class="card-reveal show2">
                            <span class="card-title">Card Title</span> <button type="button" class="close ms" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                            <p>Here is some more information about this product that is only revealed once clicked on.</p>
                            </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card">
                            <div class="card-image">
                                <div class="wrap">
                                <img class="img-fluid" src="assets/img/3.jpg" alt="image 3"/>
                                </div>
                                </div> 
                                <div class="card-content bg-light text-dark">
                                <span class="card-title">Lorem Ipsum Text</span>         
                                    <button type="button" id="show3" data-target="show3" class="show btn btn-custom float-right" aria-label="Left Align">
                                    <i class="fa fa-ellipsis-v"></i>
                                </button>
                                </div>
                        <div class="card-reveal show3">
                            <span class="card-title">Card Title</span> <button type="button" class="close ms" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                            <p>Here is some more information about this product that is only revealed once clicked on.</p>
                            </div>
                            </div>
                        </div>
                        </div>
             </div>
            </section>
            {/* <!----contact-form----->
            <!----contact-form-----> */}
        <section class="ftco-section  ">
                <div class="overlay"></div>
                        <div class="container">
                            <div class="row">
                            <div class="col-md-6">
                                <div class="support">
                                <img src="assets/img/5.jpg" alt=""/>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="sup_t">
                                <div class="text_t">
                        <h4>Lorem ipsum dolor sit amet</h4>
                                <p class="text-white">
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officia, ea optio eos perspiciatis dicta, id aliquid minima delectus vitae harum doloribus, porro possimus dolores eius sed assumenda corporis in unde!</p>
                                <p class="text-white">
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officia, ea optio eos perspiciatis dicta, id aliquid minima delectus vitae harum doloribus, porro possimus dolores eius sed assumenda corporis in unde!</p>
                                    <p class="text-white">
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officia, ea optio eos</p>
                                </div>
                                </div>
                            </div>
                            </div>
                            </div>
                        
                        <div class="container mt-5">
                            <div class="row">
                            
                            <div class="col-md-6">
                                <div class="sup_t">
                                <div class="text_t">
                        <h4>Lorem ipsum dolor sit amet</h4>
                                <p class="text-white">
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officia, ea optio eos perspiciatis dicta, id aliquid minima delectus vitae harum doloribus, porro possimus dolores eius sed assumenda corporis in unde!</p>
                                <p class="text-white">
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officia, ea optio eos perspiciatis dicta, id aliquid minima delectus vitae harum doloribus, porro possimus dolores eius sed assumenda corporis in unde!</p>
                                    <p class="text-white">
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officia, ea optio eos</p>
                                </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="support">
                                <video controls>
            <source src="http://learn.shayhowe.com/assets/misc/courses/html-css/adding-media/earth.ogv" type="video/ogg"/>
            <source src="http://learn.shayhowe.com/assets/misc/courses/html-css/adding-media/earth.mp4" type="video/mp4"/>

            </video>
                                </div>
                            </div>
                            </div>
                            </div>
                        
		</section>




</div>
    )
}

export default Suport;
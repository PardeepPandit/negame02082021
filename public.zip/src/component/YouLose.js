import React, { Fragment ,useEffect,useContext} from 'react'
import {Link} from 'react-router-dom'
import PlayOnlineContext from './playonline/context/playOnlineContext'
import {useTimerConsumerUpdate} from './MyComponent/TimerContext'


export const YouLose = () => {
  
    const playOnlineContext=useContext(PlayOnlineContext)
    const {word_definition,resetState,winner_loser,saveWord,onlineUser,matchRound,round_online, get_word}=playOnlineContext

const {data}=get_word || {}
const {word}=data || {}
/*      let {gamestatus,word}=''

    if(get_word)
    {
      gamestatus=get_word.data.gamestatus
    } */
 
    const {resetTime}=useTimerConsumerUpdate()

     useEffect(()=>{
        if(winner_loser==='loser')
        {
            console.log("Sending Status* =",onlineUser)
             matchRound(
                {
                    id:onlineUser.user1.id,
                    round:round_online,
                    status:"0",
                    points:"0"
                }
            )
        saveWord({
            match_id:onlineUser.user1.match_id,
            gamestatus:'3'
           // openstatus:'0'

        }) 
    }
    },[winner_loser]) 


    const onClick=()=>{
        console.log("You Lose")
        resetState()
        console.log("Time Reset@@@@@@@@@@@@@  1")
        resetTime()
    
    }
    return (

        <Fragment>
           
            <div className="section_card_ga section_card">
                <div className="container">
                    <div className=" row">
                    <div className="col-lg-6 mb-5 offset-md-3"><div className="logo-wrapper"><img src="assets/img/logo-01copy.png" alt="" /><h1>The Never Ending Game</h1></div></div>

                        <div className="col-md-12 ">
                            <div className=" min_top cus-padd">
                                <div className="win-container">
                                    <div className="win-wrapper">
                                        <div className="star-box lose-box">
                                            <span>X</span>
                                        </div>

                                        <h1 className="win-text lose-text">Forfeited</h1>
                                      {/*   <h3>{word}</h3> */}
                                        <h3>word is complete after check</h3>
                                        <h3>Lost</h3>
                                        <Fragment>
                                                <h1><span style={{color:'white'}}>{word_definition.word}</span></h1>
                                                <h1><span style={{color:'white'}}>{word_definition.definition}</span></h1>
                                        </Fragment>
                                       {/*  {gamestatus==="3" ? " " : 

                                            <Fragment>
                                                <h1><span style={{color:'white'}}>{word_definition.word}</span></h1>
                                                <h1><span style={{color:'white'}}>{word_definition.definition}</span></h1>
                                            </Fragment>
                                        } */}

                                        <Link to='/playonline' onClick={()=>onClick()} className='play-again' >Next-Round</Link>
                                      
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </Fragment>


    );


}

export default YouLose
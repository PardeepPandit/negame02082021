import React from 'react';


const Notifiction = () => {
    return(
<div>
    <div className="container">
        <div className="row">
        <div className="col-md-12">
            <h2 className="text-center">About Us</h2>
        </div>
        <div className="col-md-6">
                 <div className="text_l card">
                 <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                          Lorem Ipsum has been the industry's 
                          standard dummy text ever since the 1500s, 
                          when an unknown printer took a galley of type and scrambled it to make a
                           type specimen book. It has  </p>
                 <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                          Lorem Ipsum has been the industry's 
                          standard dummy text ever since the 1500s, 
                          when an unknown printer took a galley of type and scrambled it to make a
                           type specimen book. It has  </p>
                 </div>
             </div>
             <div className="col-md-6">
                 <div className="r_image">
                 <img class="w-100" src="assets/img/image1.jpg" alt="add"/>
                 </div>
             </div>
        </div>
    </div>
</div>
    )
}

export default Notifiction;
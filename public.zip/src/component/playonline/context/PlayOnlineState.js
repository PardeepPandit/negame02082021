import axios from 'axios'
import React,{useReducer,useEffect,useContext} from 'react'
import PlayOnlineContext from './playOnlineContext'
import playOnlineReducer from './playOnlineReducer'
import CommonContext from '../../MyComponent/context/common/commonContext'
import ChallengePopup from '../../playonline/play_online_components/ChallengePopup'
import {SEARCH_ONLINE,SET_LOADING,SAVE_WORD, 
    SET_INPUT_TEXT,GET_WORD,
    GET_WORD_FAIL,
    TURN_CHANGE,
    SET_WORD_DEFINITION,
    SET_RESULT,
    RESET_STATE,
    SET_GAME_TYPE,
    SET_ROUND_COMPLETE,
    SET_POPUP,
    API_HIT
} from '../../../type'
const PlayOnlineState=({children})=>{

const initialState={
onlineUser:null,
save_word:null,
get_word:null,
loading:false,
turn_change:null,
word_definition:{word:"",definition:""},
winner_loser:null,
round_online:1,
info:[],
game_type:null,
match_round:null,
round_complete:false,
popdisabled:false,
getwordapihit:null
}

const [state, dispatch] = useReducer(playOnlineReducer, initialState)

const commonContext=useContext(CommonContext)
const{inputText,setInputText}=commonContext


const setPopup=(true_false)=>{
    dispatch({
        type:SET_POPUP,
        payload:true_false
    })
}

const exitUser=async(id)=>{
    const config={
        headers:{
            'Context-type':'appplication/json',
            'APPKEY' :'Py9YJXgBecbbqxjRVaHarcSnJyuzhxGqJTkY6xKZRfrdXFy72HPXvFRvfEjy'
        }
    }
    try {

        const res=await axios.get(process.env.REACT_APP_BASEURL+`/api/user/exit?user_id=${id}`,config)
        console.log("Response from ExitUser",res.data)
    }
    catch(error){
        console.log("Exit user Error=",error)
    }
}

const setRoundComplete=(true_false)=>{

    console.log("set Round complete called=",true_false)

    dispatch({
        type:SET_ROUND_COMPLETE,
        payload:true_false
    })
}

const matchRound=async(formdata)=>{

    console.log("Form data for match round=",formdata)
    
    const config={
        headers:{
            'Context-type':'appplication/json',
            'APPKEY' :'Py9YJXgBecbbqxjRVaHarcSnJyuzhxGqJTkY6xKZRfrdXFy72HPXvFRvfEjy'
        }
    }
    const {id,round,status,points}=formdata
    const body=formdata
    try {

        const res=await axios.post(process.env.REACT_APP_BASEURL+'/api/match/round',body,config)
        /* const res=await axios.post(process.env.REACT_APP_BASEURL+`/api/match/round?id=${id}&round=${round}&status=${status}&points=${points}`,config) */
        console.log("Response from match round",res.data)
    }
    catch(error){
        console.log("Match Round Error=",error)
    }

}


const searchUserOnline=async(id)=>{
    console.log("getting data for online user id=",id)
    //search opponent for 120 seconds
    let time=120
   let myinterval=setInterval(async()=>{

    setLoading()
    
    const config={
        headers:{
            'Context-type':'appplication/json',
            'APPKEY' :'Py9YJXgBecbbqxjRVaHarcSnJyuzhxGqJTkY6xKZRfrdXFy72HPXvFRvfEjy'
        }
    }
    try {

        const res=await axios.get(process.env.REACT_APP_BASEURL+`/api/start/match?user_id=${id}&level=1`,config)
        console.log("Response from search_user_online",res.data)

        if(JSON.stringify(res.status)==='200' && JSON.stringify(res.data.status)==='200')
        {
            dispatch({
                type:SEARCH_ONLINE,
                payload:res.data
            })
            
            state.info.push({
                round:state.round_online
            })
            localStorage.setItem('info',JSON.stringify(state.info))
            clearInterval(myinterval)
        }
        else if(time===0){
            dispatch({
                type:SEARCH_ONLINE,
                payload:'opponent_not_found'
            })
            clearInterval(myinterval)

            console.log("STOP=",time)
        }
        time--
        console.log("Time=",time)
    } catch (error) {
        
    }
   },1000)
  
}
////////////////////////////////////////////////SAVE WORD
const saveWord=async(formData)=>{
    const {user_id,match_id,word,gamestatus}=formData
    const config={
        headers:{
            'Context-type':'appplication/json',
            'APPKEY' :'Py9YJXgBecbbqxjRVaHarcSnJyuzhxGqJTkY6xKZRfrdXFy72HPXvFRvfEjy'
        }
    }

    const body=formData
    console.log("body=",body)
    try {

        const res=await axios.post(process.env.REACT_APP_BASEURL+`/api/save/word`,body,config)
        console.log("Response from saveWord=",res.data)

        if(JSON.stringify(res.status)==='200' && JSON.stringify(res.data.status)==='200'){
        dispatch({
            type:SAVE_WORD,
            payload:res.data
        })
        /* if(!state.result){
                console.log("calling getWord from saveword")
            getWord(match_id,user_id,60)
        } */

        if(res.data.status===200){
            console.log("calling getword API form saveword")
            getWord(match_id,user_id,60)
        }
        else{
            console.log("NOT CALLING getword API from saveWord")
        }
            
   
    }
    } catch (error) {
        console.log("Error from savewrod API=",error)
    }

}
//////////////////////////////      GET WORD
const getWord=async(match_id,user_id,time)=>{

    
    let myinterval=setInterval(async()=>{
    setLoading()
    const config={
        headers:{
            'Context-type':'appplication/json',
            'APPKEY' :'Py9YJXgBecbbqxjRVaHarcSnJyuzhxGqJTkY6xKZRfrdXFy72HPXvFRvfEjy'
        }
    }
        //console.log("matchid=",match_id)
    try {

        const res=await axios.get(process.env.REACT_APP_BASEURL+`/api/get/word?match_id=${match_id}`,config)
       console.log("Response from getWord=",res.data)

       const{concede,gamestatus,challenge}=res.data.data
         //console.log("Response from getWord=",user_id,",",res.data.data.user_id,",",res.data.data.word,",",time)

        if(JSON.stringify(res.status)==='200' && JSON.stringify(res.data.status)==='200'){
        dispatch({
            type:GET_WORD,
            payload:res.data
        })
    }
    console.log(time,",",JSON.stringify(res.status),",",JSON.stringify(res.data.status),",",res.data.data.word,",",user_id,",",parseInt(res.data.data.user_id))

        setApiHit(time)
        if(time<0 || 
            (JSON.stringify(res.status)==='200' &&
             JSON.stringify(res.data.status)==='200' && 
             res.data.data.word && 
             user_id!==parseInt(res.data.data.user_id)))
        {
            console.log("STOP CALLING GET WORD",user_id,",",parseInt(res.data.data.user_id),",",time)
            if(res.data.data.word.length===36){
                alert("word length==36")
            }

            console.log("Setting input text  1=",res.data.data.word)
           
            if(concede==="0" && gamestatus==="0" && challenge==="0")
            {
                console.log("*************SPECIAL CASE***********")
                setInputText()
            }
            else{
                setInputText(res.data.data.word)
            }
            
            if(gamestatus==="101" || gamestatus==="3")
            {
                getWordDefinition(res.data.data.word)
                setwinnerLoser('loser')
            }
            else if(gamestatus==="5")
            {
                setwinnerLoser('winner')
            }

            setTurn(true)
            clearInterval(myinterval)
        }
        else if(res.data.data.word==="") {
            console.log("Setting input text  2=",res.data.data.word)
            setInputText('')
        }

        if(JSON.stringify(res.status)==='200' && JSON.stringify(res.data.status)==='400'){
        dispatch({
            type:GET_WORD_FAIL,
            payload:null
        })
    }
    } catch (error) {
        console.log("Error from Get Word=",error)
        
    }
    time=time-1
},1000)

}

////////////////////////////////////////////////// CHECK WORD

const getWordDefinition=async(word)=>{
   
          try {
            const config={
            headers:{
              'APPKEY': 'Py9YJXgBecbbqxjRVaHarcSnJyuzhxGqJTkY6xKZRfrdXFy72HPXvFRvfEjy'
            }
          }
          const body=
          {
              word:word
          }
            
          const res =await axios.post(process.env.REACT_APP_BASEURL+'/api/get/words/meaning',body,config)
         
          console.log("word meaning=====>",res.data)
          if(JSON.stringify(res.data.status)==='400'){
            console.log("setting demo word")
            //setResultWord({word:inputText ,definition:res.data.error_message})
            dispatch({
              type:SET_WORD_DEFINITION,
              payload:{word:inputText,definition:''}
              /* payload:{word:inputText ,definition:res.data.error_message} */
            })
            setwinnerLoser('loser')
          }
          //console.log("word meaning=====>",res.data.data.definition) 
          if(JSON.stringify(res.data.status)==='200'){
              console.log("definition found=",res.data.data)
            dispatch({
              type:SET_WORD_DEFINITION,
              payload:res.data.data
            })
            setwinnerLoser('winner')
             //get current round no. from localstroge and increament by 1
            state.info.push({
                round:JSON.parse(localStorage.getItem('info'))[JSON.parse(localStorage.getItem('info')).length-1].round+1
            })
            //store increamented round in localstorage
            localStorage.setItem('info',JSON.stringify(state.info))
          }
          
          } catch (error) {
            //setResultWord({word:inputText,definition:''})
            dispatch({
              type:SET_WORD_DEFINITION,
              payload:{word:inputText,definition:''}
            })
          }
      
        }
       

        const setwinnerLoser=(winner_loser)=>{
            dispatch({
                type:SET_RESULT,
                payload:winner_loser
            })
        }


 ////////////////////////////////// TIMER


const setTimer=(functionCall,time)=>{

    console.log("set Timer=",functionCall,",",time)
    functionCall()

}

////////////////////////////////// TURN CHANGE

const setTurn=(flag)=>{
    dispatch({
        type:TURN_CHANGE,
        payload:flag
    })
}

const resetState=()=>{
    dispatch({
        type:RESET_STATE
    })
}
 ////////////////// SET LOADING

const setLoading=()=>{
    dispatch({
        type:SET_LOADING
    })
}

const gameType=(type)=>{
    dispatch({
        type:SET_GAME_TYPE,
        payload:type
    })
}


const setApiHit=(count)=>{
    dispatch({
        type:API_HIT,
        payload:count
    })
}


    return(
        <PlayOnlineContext.Provider 
        value={{
            onlineUser:state.onlineUser,
            loading:state.loading,
            save_word:state.save_word,
            get_word:state.get_word,
            turn_change:state.turn_change,
            word_definition:state.word_definition,
            winner_loser:state.winner_loser,
            round_online:state.round_online,
            game_type:state.game_type,
            match_round:state.match_round,
            round_complete:state.round_complete,
            popdisabled:state.popdisabled,
            getwordapihit:state.getwordapihit,
            setLoading,
            searchUserOnline,
            saveWord,
            getWord,
            setTimer,
            setTurn,
            getWordDefinition,
            resetState,
            exitUser,
            gameType,
            matchRound,
            setRoundComplete,
            setwinnerLoser,
            setPopup,
            setApiHit
        }}>
            {children }

        </PlayOnlineContext.Provider>
    )
}

export default PlayOnlineState
import {createContext} from 'react'

const playOnlineContext=createContext()

export default playOnlineContext
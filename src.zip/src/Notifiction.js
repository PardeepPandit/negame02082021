import { Component} from 'react';


const Notification = () => {
    return(
<div>
    <h1>Hello</h1>
<div class="man">
        <div class="container">
            <div class="row">
             <div class="col-md-12">
                 <div class="card noti p-4 mt-3 ">
                     <p><strong>Vadpal</strong> <a  class="pull-right lin_k" href="#"> New Link</a></p>
                     <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odio consequatur eos eaque nihil adipisci quasi incidunt quod quos necessitatibus saepe sit earum expedita iure, dicta distinctio laudantium, </p>
                 </div>
                  <div class="card noti p-4 mt-3 ">
                     <p><strong>Vadpal</strong> <a  class="pull-right lin_k" href="#"> New Link</a></p>
                     <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odio consequatur eos eaque nihil adipisci quasi incidunt quod quos necessitatibus saepe sit earum expedita iure, dicta distinctio laudantium, </p>
                 </div>
                  <div class="card noti p-4 mt-3 ">
                     <p><strong>Vadpal</strong> <a  class="pull-right lin_k" href="#"> New Link</a></p>
                     <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odio consequatur eos eaque nihil adipisci quasi incidunt quod quos necessitatibus saepe sit earum expedita iure, dicta distinctio laudantium, </p>
                 </div>
                  <div class="card noti p-4 mt-3 ">
                     <p><strong>Vadpal</strong> <a  class="pull-right lin_k" href="#"> New Link</a></p>
                     <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odio consequatur eos eaque nihil adipisci quasi incidunt quod quos necessitatibus saepe sit earum expedita iure, dicta distinctio laudantium, </p>
                 </div>
                  <div class="card noti p-4 mt-3 ">
                     <p><strong>Vadpal</strong> <a  class="pull-right lin_k" href="#"> New Link</a></p>
                     <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odio consequatur eos eaque nihil adipisci quasi incidunt quod quos necessitatibus saepe sit earum expedita iure, dicta distinctio laudantium, </p>
                 </div>
                  <div class="card noti p-4 mt-3 ">
                     <p><strong>Vadpal</strong> <a  class="pull-right lin_k" href="#"> New Link</a></p>
                     <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odio consequatur eos eaque nihil adipisci quasi incidunt quod quos necessitatibus saepe sit earum expedita iure, dicta distinctio laudantium, </p>
                 </div>
                  <div class="card noti p-4 mt-3 ">
                     <p><strong>Vadpal</strong> <a  class="pull-right lin_k" href="#"> New Link</a></p>
                     <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odio consequatur eos eaque nihil adipisci quasi incidunt quod quos necessitatibus saepe sit earum expedita iure, dicta distinctio laudantium, </p>
                 </div>
                  <div class="card noti p-4 mt-3 ">
                     <p><strong>Vadpal</strong> <a  class="pull-right lin_k" href="#"> New Link</a></p>
                     <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odio consequatur eos eaque nihil adipisci quasi incidunt quod quos necessitatibus saepe sit earum expedita iure, dicta distinctio laudantium, </p>
                 </div>
             </div>
            
                 
        </div>
    </div>
    </div>
    
</div>
    )
}

export default Notification;
import React  from 'react';
import { Container, Row,Col } from 'reactstrap';






function About (){
    return(
        <div>
<Container>
    <Row>
        <Col md={6}>sfsa</Col>
        <Col md={6}>safas</Col>
    </Row>
</Container>
        </div>
    )
}

export default About;

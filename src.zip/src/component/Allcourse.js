import React from  "react";
import { Button } from "reactstrap";



function Allcourese(){
return(
    <div>
        <h1>Allcourese</h1>
        <Button outline color="primary" className="ml-2">primary</Button>
    </div>

)
}





export default Allcourese;



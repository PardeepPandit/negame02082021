import React from 'react';



const Hint = (props) => {
  
  
  return (
  
<h-me>

   <div class="section_card registration-container">
       <div class="container container-xl">
       
       <div class="row">
       <div className="col-lg-5"></div>
       <div className="col-lg-7">
        <h1 className="country-hdng">Buy Hint</h1>
       </div>

       <div className="col-lg-5">
                <div className="profile-card">
                    <div className="profile-icon infoicon">
                    <img src="assets/img/image1.jpg" alt="" className="img-fluid" />
                    </div>
                    <h1 className="profile-name">Ved Pal</h1>
                    <div className="number-box">
                    <h2>Rank 3</h2>
                    <h2>Points 8</h2>
                    </div>
                </div>
            </div>

            <div className="col-lg-7">
                <div className="hint-panel">
                <div className="row">
                <div className="col">
                    <div className="hint-box">
                    <h2>1</h2>
                    </div>
                </div>

                <div className="col">
                    <div className="hint-box">
                    <h2>1</h2>
                    </div>
                </div>

                <div className="col">
                    <div className="hint-box">
                    <h2>1</h2>
                    </div>
                </div>

                <div className="col">
                    <div className="hint-box">
                    <h2>1</h2>
                    </div>
                </div>

                <div className="col">
                    <div className="hint-box">
                    <h2>1</h2>
                    </div>
                </div>

                <div className="col">
                    <div className="hint-box">
                    <h2>1</h2>
                    </div>
                </div>

                <div className="col">
                    <div className="hint-box">
                    <h2>1</h2>
                    </div>
                </div>

                <div className="col">
                    <div className="hint-box">
                    <h2>1</h2>
                    </div>
                </div>

                <div className="col">
                    <div className="hint-box">
                    <h2>1</h2>
                    </div>
                </div>

                <div className="col">
                    <div className="hint-box">
                    <h2>1</h2>
                    </div>
                </div>

                <div className="col">
                    <div className="hint-box">
                    <h2>1</h2>
                    </div>
                </div>

                <div className="col">
                    <div className="hint-box">
                    <h2>1</h2>
                    </div>
                </div>

                <div className="col">
                    <div className="hint-box">
                    <h2>1</h2>
                    </div>
                </div>

                <div className="col">
                    <div className="hint-box">
                    <h2>1</h2>
                    </div>
                </div>

                <div className="col">
                    <div className="hint-box">
                    <h2>1</h2>
                    </div>
                </div>

                <div className="col">
                    <div className="hint-box">
                    <h2>1</h2>
                    </div>
                </div>

                <div className="col">
                    <div className="hint-box">
                    <h2>1</h2>
                    </div>
                </div>

                <div className="col">
                    <div className="hint-box">
                    <h2>1</h2>
                    </div>
                </div>

                <div className="col">
                    <div className="hint-box">
                    <h2>1</h2>
                    </div>
                </div>

                <div className="col">
                    <div className="hint-box">
                    <h2>1</h2>
                    </div>
                </div>

                <div className="col">
                    <div className="hint-box">
                    <h2>1</h2>
                    </div>
                </div>

                <div className="col">
                    <div className="hint-box">
                    <h2>1</h2>
                    </div>
                </div>

                <div className="col">
                    <div className="hint-box">
                    <h2>1</h2>
                    </div>
                </div>

                <div className="col">
                    <div className="hint-box">
                    <h2>1</h2>
                    </div>
                </div>

                <div className="col">
                    <div className="hint-box">
                    <h2>1</h2>
                    </div>
                </div>

                </div>
                </div>                

                <div className="row">
                    <div className="col-lg-12">
                        <a href="#" className="buynow-btn">Buy Now</a>
                    </div>
                </div>

            </div>
            
       </div>
      
       </div>
   </div>
   
    
</h-me>


  );


}

export default Hint;
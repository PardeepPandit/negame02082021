import React,{Fragment} from 'react'

export const LeftAdd = () => {
    return (
        <Fragment>
            <div className="col-lg-2">
                <img src="assets/img/ad4.jpg" alt="" className="img-fluid" />
            </div>                    
        </Fragment>
    )
}

export default LeftAdd
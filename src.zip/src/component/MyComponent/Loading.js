import loading from './loading.gif'

const Loading=()=>{

return(
    <img src={loading} alt="Loading..." style={{width:'100px',margin:'auto',marginTop:'400px',display:'block',height:'100%'}}/> 
)
}

export default Loading
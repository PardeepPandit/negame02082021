import React from 'react'

const NotFoundPage=()=>{
    return(
            <h1>SOMETHING WRONG.....</h1>
    )
}

export default NotFoundPage
import {createContext} from 'react'

const commonContext=createContext()

export default commonContext
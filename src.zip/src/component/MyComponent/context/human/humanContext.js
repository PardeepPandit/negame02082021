import {createContext} from 'react'

const humanContext=createContext()

export default humanContext
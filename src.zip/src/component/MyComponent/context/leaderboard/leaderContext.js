import {createContext} from 'react'

const leaderContext=createContext()

export default leaderContext 